-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 14, 2021 at 02:13 PM
-- Server version: 5.7.26
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `login` text NOT NULL,
  `admin_pass` text NOT NULL,
  `admin_email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `login`, `admin_pass`, `admin_email`) VALUES
(1, 'Admin Victory', 'admin', 'admin', 'admin-vic@mail.ru');

-- --------------------------------------------------------

--
-- Table structure for table `cart_test`
--

CREATE TABLE `cart_test` (
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sum` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart_test`
--

INSERT INTO `cart_test` (`cart_id`, `product_id`, `count`, `user_id`, `sum`) VALUES
(21, 1, 1, 0, 2700),
(22, 2, 1, 0, 3400),
(23, 3, 1, 0, 2500),
(24, 4, 1, 0, 2400);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `sum` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(60) DEFAULT 'Размещен'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `product_id`, `count`, `sum`, `user_id`, `date`, `status`) VALUES
(8, 2, 1, 3400, 9, '2021-05-14 12:50:39', 'Отгружен'),
(9, 4, 1, 2400, 9, '2021-05-14 12:50:39', 'Отгружен'),
(10, 1, 1, 2700, 9, '2021-05-14 12:50:39', 'Отгружен'),
(11, 3, 1, 2500, 10, '2021-05-14 12:51:08', 'Отменен'),
(12, 4, 1, 2400, 10, '2021-05-14 12:51:08', 'Отгружен');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `price` int(11) NOT NULL,
  `shortdesc` text NOT NULL,
  `fulldesc` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `price`, `shortdesc`, `fulldesc`, `img`) VALUES
(1, 'Влестелин колец. Подарочное издание', 2700, 'Подарочное издание в кожаном переплете с золотым и блинтовым тиснением, трехсторонним художественно окрашенным обрезом и шелковым ляссе.', 'Перед вами трилогия \"Властелин колец\". Своеобразная \"Библия от фэнтези\". Книга Книг ХХ века. Самое популярное, самое читаемое, самое культовое произведение ушедшего столетия. Не легенда литературы, но миф! Впрочем... писать о \"Властелине колец\" можно много, почти бесконечно, но - зачем? Комментарии здесь излишни. Властелин колец. Трилогия: Хранители. Две твердыни. Возвращение государя.', 'book-1.png'),
(2, 'Гарри Поттер. Подарочное издание', 3400, 'Книга, покорившая мир, эталон литературы для читателей всех возрастов, синоним успеха. Книга, сделавшая Дж.К. Роулинг самым читаемым писателем современности.', 'Книга, покорившая мир, эталон литературы для читателей всех возрастов, синоним успеха. Книга, сделавшая Дж.К. Роулинг самым читаемым писателем современности. Книга, ставшая культовой уже для нескольких поколений. \r\nПолное собрание серии в подарочном футляре.', 'book-2.jpg'),
(3, 'Игра престолов. Подарочное издание', 2500, 'Подарочное издание в кожаном переплете с золотым и блинтовым тиснением, трехсторонним художественно окрашенным обрезом и шелковым ляссе.', 'ТАНЦЕМ ДРАКОНОВ издавна звали в Семи Королевствах войну. Но теперь война охватывает все новые и новые земли. \r\nВойна катится с Севера - из-за Стены. Война идет с Запада - с Островов. Войну замышляет Юг, мечтающий посадить на Железный Трон свою ставленницу. И совсем уже неожиданную угрозу несет с Востока вошедшая в силу \"мать драконов\" Дейенерис... \r\nЧто будет? Кровь и ненависть. Любовь и политика. И прежде всего - судьба, которой угодно было свести в смертоносном танце великие силы.', 'book-3.png'),
(4, 'Хроники Нарнии. Подарочное издание', 2400, 'Прекрасно оформленное подарочное издание в тканевом переплете с золотым тиснением, трехсторонним золотым обрезом и шелковым ляссе.', 'Прекрасно оформленное подарочное издание в тканевом переплете с золотым тиснением, трехсторонним золотым обрезом и шелковым ляссе. \r\n\"Хроники Нарнии\" - удивительная и прекрасная история волшебной страны, в которой правят любовь и доброта, где животные и птицы говорят и мыслят подобно людям, а в лесах обитают гномы и великаны, фавны и кентавры. Наряду с \"Властелином колец\" Дж.Р.Р.Толкина, \"Хроники Нарнии\" стали мировой классикой фэнтези, одинаково любимой многими поколениями детей и взрослых.', 'book-4.png');

-- --------------------------------------------------------

--
-- Table structure for table `users_test`
--

CREATE TABLE `users_test` (
  `user_id` int(11) NOT NULL,
  `user_name` text,
  `login` varchar(20) NOT NULL,
  `user_pass` text NOT NULL,
  `user_email` text NOT NULL,
  `phone` text,
  `address` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_test`
--

INSERT INTO `users_test` (`user_id`, `user_name`, `login`, `user_pass`, `user_email`, `phone`, `address`) VALUES
(9, 'Max', 'max_p', '123123', 'max_p@mail.ru', '+79262662626', 'укп ыер фке'),
(10, 'Ann', 'ann_25', '123123', 'ann@mail.ru', '+79262662626', 'trgwrgtw wr');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart_test`
--
ALTER TABLE `cart_test`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users_test`
--
ALTER TABLE `users_test`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart_test`
--
ALTER TABLE `cart_test`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_test`
--
ALTER TABLE `users_test`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
